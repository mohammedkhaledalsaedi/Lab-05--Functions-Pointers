#include <stdio.h>

int main() {
    
    char charArray[5];
    int intArray[5];
    short shortArray[5];
    double doubleArray[5];

  
    printf("Memory addresses of charArray:\n");
    for (int i = 0; i < 5; i++) {
        printf("%p\n", &charArray[i]);
    }

 
    printf("\nMemory addresses of intArray:\n");
    for (int i = 0; i < 5; i++) {
        printf("%p\n", &intArray[i]);
    }

  
    printf("\nMemory addresses of shortArray:\n");
    for (int i = 0; i < 5; i++) {
        printf("%p\n", &shortArray[i]);
    }

  
    printf("\nMemory addresses of doubleArray:\n");
    for (int i = 0; i < 5; i++) {
        printf("%p\n", &doubleArray[i]);
    }

    return 0;
}

