#include <stdio.h>


int main() {

	int a = 3;


	int *ptr;
	ptr = &a;


	char *p = (char*)&a;
	char *p1= (char*)&a+1;


        

	printf("the value of a is:  %d\n", a);
	printf("the address of a from integer pointer is :%p\n", ptr);
	printf("the value of *ptr which is a is: %d\n", *ptr);

       
	
	printf("the address of a but this time from a character pointer: %p\n", p);
	printf("the value of the character pointer: %d\n", *p);
	printf("the value of address + 1: %d\n", *p1);


	if (*ptr == *p) {


		printf("It is litte endian\n");
	}
	else {
		printf("It is big endian");
	}



	printf("The following is the architcture of my system: \n");

	if (sizeof(&ptr) == 8) {

		printf("It is 64 bit");
	}
	else if (sizeof(&ptr) == 4) {

		printf("It is 32 bit\n");
	}

	printf("\n");


	return 0;
}
