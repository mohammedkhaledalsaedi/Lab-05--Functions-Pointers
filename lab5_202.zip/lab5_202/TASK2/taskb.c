#include <stdio.h>

int main( ) {

	int *ptr;

	if (sizeof(&ptr)==8)
	{
		printf("its 64 bit");
	}
	else if (sizeof(&ptr)==4){
		printf("its 32bit");
	}



}
