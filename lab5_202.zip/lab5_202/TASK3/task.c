#include <stdio.h>

//integer add
int add_int(int a, int b) {

	return a+b;
}


//float addd
float add_flo(float a, float b) {

	return a+b;
}


// function for the area of the circle:


float circleArea(float a) {

	return 3.14 * (a*a);
}

//triangle area

int rect(int a, int b) {

	return a*b;
}


int factorial(int n) {

	if (n==0) {

		return 1;
	}
	else
		return n * factorial(n - 1);
}


int main() {

	int num1 = 5;
	int num2 = 6;
	int out;
	out = add_int(num1, num2);
	printf("%d\n", out);


	float num3 = 12;
	float num4 = 10;
	float output;

	output = add_flo(num3, num4);
	printf("%.2f\n", output);


	float radius;
	printf("enter the radius: \n");
	scanf("%f", &radius);

	printf("the radius is: %f\n", circleArea(radius));


	int width;
	int length;
	printf("enter the width: \n");
	scanf("%d", &width);
	printf("enter the length: \n");
	scanf("%d", &length);

	printf("the area of rectangular is :%d\n", rect(width, length));




	int n;

	printf("enter any nymber to see its factorial: ");
	scanf("%d", &n);

	printf("The factorial result is: %d\n ", factorial(n));






	return 0;
}
