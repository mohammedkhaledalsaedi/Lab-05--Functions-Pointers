#include <stdio.h>

int StringLength(char sentence[]) {
    int L = 0;
    while (sentence[L] != '\0') {
        L++;
    }
    return L;
}

int NumOfWords(char sentence[], int strLength) {
    int count = 0;
    int inWord = 0;

    for (int i = 0; i < strLength; i++) {
        if (sentence[i] == ' ' || sentence[i] == '\n' || sentence[i] == '\t') {
            inWord = 0;
        } else if (inWord == 0) {
            inWord = 1;
            count++;
        }
    }
    return count;
}

int NumOfVowels(char sentence[], int strLength) {
    int count = 0;
    for (int i = 0; i < strLength; i++) {
        char ch = sentence[i];
        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
            ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
            count++;
        }
    }
    return count;
}

int VowelFreq(char sentence[], char vowel) {
    int count = 0;
    for (int i = 0; sentence[i] != '\0'; i++) {
        if (sentence[i] == vowel || sentence[i] == vowel + 32 || sentence[i] == vowel - 32) {
            count++;
        }
    }
    return count;
}

int main() {
    char sentence[100];
    int i = 0;

    printf("Enter a sentence (max 100 characters): ");

    while (i < 99 && (sentence[i] = getchar()) != '\n') {
        i++;
    }
    sentence[i] = '\0';

    int L = StringLength(sentence);
    printf("Length of the sentence: %d\n", L);

    int wordCount = NumOfWords(sentence, L);
    printf("Number of words in the sentence: %d\n", wordCount);

    int vowelCount = NumOfVowels(sentence, L);
    printf("Number of vowels in the sentence: %d\n", vowelCount);

    char vowels[] = {'a', 'e', 'i', 'o', 'u'};
    for (int j = 0; j < 5; j++) {
        int freq = VowelFreq(sentence, vowels[j]);
        printf("Frequency of '%c': %d\n", vowels[j], freq);
    }

    return 0;
}

